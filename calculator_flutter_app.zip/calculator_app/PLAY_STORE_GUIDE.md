# Calculator App — Play Store Publishing Guide

## ফাইল স্ট্রাকচার
```
calculator_app/
├── lib/
│   └── main.dart         ← মূল app কোড
├── android/
│   └── app/
│       ├── build.gradle
│       └── src/main/
│           └── AndroidManifest.xml
└── pubspec.yaml
```

---

## ধাপ ১ — Flutter ইন্সটল করুন

1. https://flutter.dev/docs/get-started/install এ যান
2. Windows/Mac/Linux অনুযায়ী ডাউনলোড করুন
3. Terminal/CMD-এ চালান:
   ```
   flutter doctor
   ```
   সব ✓ চিহ্ন দেখালে প্রস্তুত।

---

## ধাপ ২ — Project সেটআপ

```bash
# নতুন Flutter project তৈরি করুন
flutter create calculator_app
cd calculator_app

# দেওয়া main.dart দিয়ে replace করুন
# lib/main.dart ফাইলটা copy করুন
```

---

## ধাপ ৩ — Test করুন (Emulator বা Real Device)

```bash
flutter run
```

---

## ধাপ ৪ — Release APK/AAB তৈরি করুন

### Keystore বানান (একবারই করতে হবে):
```bash
keytool -genkey -v -keystore ~/my-release-key.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias my-key-alias
```

### android/app/build.gradle-এ signing config যোগ করুন:
```gradle
signingConfigs {
    release {
        keyAlias 'my-key-alias'
        keyPassword 'আপনার পাসওয়ার্ড'
        storeFile file('/home/user/my-release-key.jks')
        storePassword 'আপনার পাসওয়ার্ড'
    }
}
```

### AAB বিল্ড করুন (Play Store এটাই চায়):
```bash
flutter build appbundle --release
```
ফাইল পাবেন: `build/app/outputs/bundle/release/app-release.aab`

---

## ধাপ ৫ — Play Store-এ Submit করুন

1. **Google Play Console** খুলুন: https://play.google.com/console
2. **$25 one-time fee** দিয়ে Developer Account খুলুন
3. **"Create app"** বাটনে ক্লিক করুন
4. নিচের তথ্য দিন:
   - App name: Calculator
   - Language: Bengali / English
   - App or game: App
   - Free or paid: Free
5. **Production → Releases → Create new release** এ AAB file আপলোড করুন
6. Store listing পূরণ করুন (description, screenshots, icon)
7. **Review and publish** করুন

---

## App Icon পরিবর্তন করতে

`pubspec.yaml`-এ যোগ করুন:
```yaml
dev_dependencies:
  flutter_launcher_icons: ^0.13.0

flutter_icons:
  android: true
  ios: false
  image_path: "assets/icon.png"
```
তারপর:
```bash
flutter pub get
flutter pub run flutter_launcher_icons
```

---

## দরকারি লিংক
- Flutter Docs: https://docs.flutter.dev
- Play Console: https://play.google.com/console
- Icon তৈরি: https://icon.kitchen
