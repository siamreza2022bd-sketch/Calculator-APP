import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  const CalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calculator',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF1C1C1E),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFFF9F0A),
        ),
      ),
      home: const CalculatorScreen(),
    );
  }
}

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String _display = '0';
  String _expression = '';
  double? _prev;
  String? _op;
  bool _justEvaled = false;

  String _format(double n) {
    if (n == n.truncateToDouble()) {
      return n.truncate().toString();
    }
    String s = n.toStringAsPrecision(10);
    // Remove trailing zeros after decimal
    if (s.contains('.')) {
      s = s.replaceAll(RegExp(r'0+$'), '').replaceAll(RegExp(r'\.$'), '');
    }
    return s;
  }

  double _calc(double a, double b, String op) {
    switch (op) {
      case '+': return a + b;
      case '−': return a - b;
      case '×': return a * b;
      case '÷': return b != 0 ? a / b : double.nan;
      default: return b;
    }
  }

  void _onButton(String label) {
    setState(() {
      if (label == 'AC') {
        _display = '0';
        _expression = '';
        _prev = null;
        _op = null;
        _justEvaled = false;
      } else if (label == '+/−') {
        if (_display != '0') {
          _display = _display.startsWith('-')
              ? _display.substring(1)
              : '-$_display';
        }
      } else if (label == '%') {
        double val = double.tryParse(_display) ?? 0;
        _display = _format(val / 100);
      } else if ('0123456789'.contains(label)) {
        if (_justEvaled) {
          _display = label;
          _justEvaled = false;
        } else {
          _display = _display == '0' ? label : (_display.length < 12 ? _display + label : _display);
        }
      } else if (label == '.') {
        if (_justEvaled) {
          _display = '0.';
          _justEvaled = false;
        } else if (!_display.contains('.')) {
          _display += '.';
        }
      } else if (['+', '−', '×', '÷'].contains(label)) {
        double cur = double.tryParse(_display) ?? 0;
        if (_op != null && !_justEvaled) {
          double res = _calc(_prev!, cur, _op!);
          _display = _format(res);
          _prev = res;
        } else {
          _prev = cur;
        }
        _op = label;
        _expression = '${_format(_prev!)} $label';
        _justEvaled = false;
      } else if (label == '=') {
        if (_op == null) return;
        double cur = double.tryParse(_display) ?? 0;
        double a = _prev ?? 0;
        _expression = '${_format(a)} $_op ${_format(cur)} =';
        double res = _calc(a, cur, _op!);
        _display = res.isNaN ? 'Error' : _format(res);
        _op = null;
        _prev = null;
        _justEvaled = true;
      }
    });
  }

  Widget _buildButton(String label, {Color? bg, Color? fg, int flex = 1}) {
    Color background = bg ?? const Color(0xFF2C2C2E);
    if (['+', '−', '×', '÷', '='].contains(label)) {
      background = bg ?? const Color(0xFFFF9F0A);
    } else if (['AC', '+/−', '%'].contains(label)) {
      background = bg ?? const Color(0xFF48484A);
    }

    Color foreground = fg ?? Colors.white;
    if (['AC', '+/−', '%'].contains(label)) {
      foreground = Colors.black;
    }

    return Expanded(
      flex: flex,
      child: Padding(
        padding: const EdgeInsets.all(6),
        child: Material(
          color: background,
          borderRadius: BorderRadius.circular(100),
          child: InkWell(
            borderRadius: BorderRadius.circular(100),
            onTap: () => _onButton(label),
            splashColor: Colors.white24,
            child: Container(
              height: label == '0' ? 78 : 78,
              alignment: label == '0' ? Alignment.centerLeft : Alignment.center,
              padding: label == '0' ? const EdgeInsets.only(left: 28) : EdgeInsets.zero,
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w400,
                  color: foreground,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1C1C1E),
      body: SafeArea(
        child: Column(
          children: [
            // Display
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                alignment: Alignment.bottomRight,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    if (_expression.isNotEmpty)
                      Text(
                        _expression,
                        style: const TextStyle(
                          fontSize: 20,
                          color: Colors.white38,
                        ),
                      ),
                    const SizedBox(height: 8),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(
                        _display,
                        style: const TextStyle(
                          fontSize: 72,
                          fontWeight: FontWeight.w300,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Buttons
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 0, 8, 16),
              child: Column(
                children: [
                  Row(children: [
                    _buildButton('AC'),
                    _buildButton('+/−'),
                    _buildButton('%'),
                    _buildButton('÷'),
                  ]),
                  Row(children: [
                    _buildButton('7'),
                    _buildButton('8'),
                    _buildButton('9'),
                    _buildButton('×'),
                  ]),
                  Row(children: [
                    _buildButton('4'),
                    _buildButton('5'),
                    _buildButton('6'),
                    _buildButton('−'),
                  ]),
                  Row(children: [
                    _buildButton('1'),
                    _buildButton('2'),
                    _buildButton('3'),
                    _buildButton('+'),
                  ]),
                  Row(children: [
                    _buildButton('0', flex: 2),
                    _buildButton('.'),
                    _buildButton('='),
                  ]),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
