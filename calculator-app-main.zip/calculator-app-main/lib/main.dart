import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  const CalculatorApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calculator',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF1C1C1E),
      ),
      home: const CalculatorScreen(),
    );
  }
}

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});
  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String _display = '0';
  String _expression = '';
  double? _prev;
  String? _op;
  bool _justEvaled = false;

  String _format(double n) {
    if (n == n.truncateToDouble()) return n.truncate().toString();
    return double.parse(n.toStringAsPrecision(10)).toString();
  }

  double _calc(double a, double b, String op) {
    switch (op) {
      case '+': return a + b;
      case '−': return a - b;
      case '×': return a * b;
      case '÷': return b != 0 ? a / b : double.nan;
      default: return b;
    }
  }

  void _onButton(String label) {
    setState(() {
      if (label == 'AC') {
        _display = '0'; _expression = ''; _prev = null; _op = null; _justEvaled = false;
      } else if (label == '+/−') {
        if (_display != '0') _display = _display.startsWith('-') ? _display.substring(1) : '-$_display';
      } else if (label == '%') {
        _display = _format((double.tryParse(_display) ?? 0) / 100);
      } else if ('0123456789'.contains(label)) {
        if (_justEvaled) { _display = label; _justEvaled = false; }
        else _display = _display == '0' ? label : (_display.length < 12 ? _display + label : _display);
      } else if (label == '.') {
        if (_justEvaled) { _display = '0.'; _justEvaled = false; }
        else if (!_display.contains('.')) _display += '.';
      } else if (['+', '−', '×', '÷'].contains(label)) {
        double cur = double.tryParse(_display) ?? 0;
        if (_op != null && !_justEvaled) { cur = _calc(_prev!, cur, _op!); _display = _format(cur); }
        _prev = cur; _op = label; _expression = '${_format(_prev!)} $label'; _justEvaled = false;
      } else if (label == '=') {
        if (_op == null) return;
        double cur = double.tryParse(_display) ?? 0;
        _expression = '${_format(_prev!)} $_op ${_format(cur)} =';
        double res = _calc(_prev!, cur, _op!);
        _display = res.isNaN ? 'Error' : _format(res);
        _op = null; _prev = null; _justEvaled = true;
      }
    });
  }

  Widget _buildButton(String label, {int flex = 1}) {
    Color bg = const Color(0xFF2C2C2E);
    Color fg = Colors.white;
    if (['+', '−', '×', '÷', '='].contains(label)) bg = const Color(0xFFFF9F0A);
    if (['AC', '+/−', '%'].contains(label)) { bg = const Color(0xFF48484A); fg = Colors.black; }
    return Expanded(
      flex: flex,
      child: Padding(
        padding: const EdgeInsets.all(6),
        child: Material(
          color: bg,
          borderRadius: BorderRadius.circular(100),
          child: InkWell(
            borderRadius: BorderRadius.circular(100),
            onTap: () => _onButton(label),
            child: Container(
              height: 78,
              alignment: label == '0' ? Alignment.centerLeft : Alignment.center,
              padding: label == '0' ? const EdgeInsets.only(left: 28) : EdgeInsets.zero,
              child: Text(label, style: TextStyle(fontSize: 28, color: fg)),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1C1C1E),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(_expression, style: const TextStyle(fontSize: 20, color: Colors.white38)),
                    const SizedBox(height: 8),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(_display, style: const TextStyle(fontSize: 72, fontWeight: FontWeight.w300, color: Colors.white)),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 0, 8, 16),
              child: Column(children: [
                Row(children: [_buildButton('AC'), _buildButton('+/−'), _buildButton('%'), _buildButton('÷')]),
                Row(children: [_buildButton('7'), _buildButton('8'), _buildButton('9'), _buildButton('×')]),
                Row(children: [_buildButton('4'), _buildButton('5'), _buildButton('6'), _buildButton('−')]),
                Row(children: [_buildButton('1'), _buildButton('2'), _buildButton('3'), _buildButton('+')]),
                Row(children: [_buildButton('0', flex: 2), _buildButton('.'), _buildButton('=')]),
              ]),
            ),
          ],
        ),
      ),
    );
  }
}